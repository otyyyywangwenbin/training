package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonBooleanFormatVisitor extends JsonValueFormatVisitor {

}
