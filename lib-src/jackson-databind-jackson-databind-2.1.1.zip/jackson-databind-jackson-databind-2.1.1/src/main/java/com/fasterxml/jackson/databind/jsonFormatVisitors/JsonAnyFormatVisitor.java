package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonAnyFormatVisitor {

}
