package com.fasterxml.jackson.databind.jsonFormatVisitors;

public interface JsonIntegerFormatVisitor extends JsonValueFormatVisitor {

}
