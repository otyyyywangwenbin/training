package com.fasterxml.jackson.databind.jsonFormatVisitors;


public interface JsonNumberFormatVisitor extends JsonValueFormatVisitor{

}
